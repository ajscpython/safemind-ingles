export default function Contato() {
  return (
    <div className="container">
      <h1>Contato</h1>
      <p>Fale com a gente pelo WhatsApp:</p>
      <a href="https://wa.me/5594991030231" target="_blank" rel="noopener noreferrer">
        <button>Enviar mensagem no WhatsApp</button>
      </a>
      <p>Email: contato@safemind.com.br</p>
    </div>
  );
}
