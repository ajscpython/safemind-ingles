export default function AreaDoAluno() {
  return (
    <div className="container">
      <h1>Área do Aluno</h1>
      <p>Em breve, você poderá acessar seu painel com aulas, pagamentos e histórico.</p>
    </div>
  );
}
